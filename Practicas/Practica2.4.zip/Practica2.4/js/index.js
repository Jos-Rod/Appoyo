var title = document.getElementById("Titulo");
var description = document.getElementById("Descripcion");

var info = [
    {
        title: "Hipsográfico",
        description: "1"
    },
    {
        title: "Volcanes",
        description: "2"
    },
    {
        title: "Magnitud Sísmica",
        description: "3"
    },
    {
        title: "Erosión Costera",
        description: "4"
    },
    {
        title: "Movimiento en Masa",
        description: "5"
    }
];

document.querySelectorAll(".btn").forEach(element => {
    element.addEventListener("click", function() {
        title.innerHTML = info[element.id - 1].title;
        description.innerHTML = info[element.id - 1].description;
    });
});